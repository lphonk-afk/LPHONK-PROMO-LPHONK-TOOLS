export type Ratio = "9:16" | "16:9" | "3:4" | "1:1";
export const RATIOS: Ratio[] = ["9:16", "16:9", "3:4", "1:1"];

export interface RenderOpts {
  image: HTMLImageElement;
  ratio: Ratio;
  song: string;
  artist: string;
  color: string;
  current: string;
  total: string;
}

export const parseTime = (t: string) => {
  if (!t || !t.includes(":")) return 0;
  const [m, s] = t.split(":");
  return (parseInt(m, 10) || 0) * 60 + (parseInt(s, 10) || 0);
};

export const progressPercent = (c: string, t: string) => {
  const total = parseTime(t);
  if (total <= 0) return 0;
  return Math.min(Math.max((parseTime(c) / total) * 100, 0), 100);
};

export const calculateCanvas = (r: Ratio) =>
  ({ "16:9": { w: 1920, h: 1080 }, "3:4": { w: 1080, h: 1440 }, "1:1": { w: 1080, h: 1080 }, "9:16": { w: 1080, h: 1920 } })[r];

interface Layout {
  cover: { x: number; y: number; size: number; radius: number };
  info: { x: number; y: number; right: number; title: number; sub: number; gap: number };
  scale: number;
}

// Each ratio gets its own composition
function layout(r: Ratio, w: number, h: number): Layout {
  if (r === "16:9") {
    const size = 760;
    const x = 140, y = (h - size) / 2;
    const ix = x + size + 110;
    return { cover: { x, y, size, radius: 32 }, info: { x: ix, y: h / 2 - 90, right: w - 140, title: 76, sub: 40, gap: 64 }, scale: 1.1 };
  }
  if (r === "1:1") {
    const size = 560;
    return { cover: { x: (w - size) / 2, y: 100, size, radius: 26 }, info: { x: 110, y: 100 + size + 80, right: w - 110, title: 50, sub: 30, gap: 44 }, scale: 0.75 };
  }
  if (r === "3:4") {
    const size = 760;
    return { cover: { x: (w - size) / 2, y: 110, size, radius: 30 }, info: { x: 130, y: 110 + size + 95, right: w - 130, title: 58, sub: 34, gap: 54 }, scale: 0.9 };
  }
  const size = 820;
  return { cover: { x: (w - size) / 2, y: 260, size, radius: 32 }, info: { x: 130, y: 260 + size + 110, right: w - 130, title: 62, sub: 36, gap: 60 }, scale: 1 };
}

function drawCoverFit(ctx: CanvasRenderingContext2D, img: HTMLImageElement, x: number, y: number, w: number, h: number) {
  const s = Math.max(w / img.width, h / img.height);
  const sw = w / s, sh = h / s;
  ctx.drawImage(img, (img.width - sw) / 2, (img.height - sh) / 2, sw, sh, x, y, w, h);
}

function fitText(ctx: CanvasRenderingContext2D, text: string, max: number) {
  if (ctx.measureText(text).width <= max) return text;
  let t = text;
  while (t.length && ctx.measureText(t + "…").width > max) t = t.slice(0, -1);
  return t + "…";
}

function drawBackground(ctx: CanvasRenderingContext2D, o: RenderOpts, w: number, h: number) {
  ctx.save();
  ctx.filter = "blur(75px) contrast(1.5) brightness(0.65) saturate(1.7)";
  drawCoverFit(ctx, o.image, -150, -150, w + 300, h + 300);
  ctx.restore();
  ctx.fillStyle = "rgba(10,10,15,0.72)";
  ctx.fillRect(0, 0, w, h);
}

function drawCover(ctx: CanvasRenderingContext2D, o: RenderOpts, L: Layout) {
  const { x, y, size, radius } = L.cover;
  ctx.save();
  ctx.shadowColor = o.color; ctx.shadowBlur = 80 * L.scale; ctx.shadowOffsetY = 20 * L.scale;
  ctx.fillStyle = "#000"; ctx.beginPath(); ctx.roundRect(x, y, size, size, radius); ctx.fill();
  ctx.restore();
  ctx.save(); ctx.beginPath(); ctx.roundRect(x, y, size, size, radius); ctx.clip();
  drawCoverFit(ctx, o.image, x, y, size, size);
  ctx.restore();
}

function drawTrackInfo(ctx: CanvasRenderingContext2D, o: RenderOpts, L: Layout) {
  const { x, y, right, title, sub, gap } = L.info;
  const maxW = right - x;
  ctx.textAlign = "left";
  ctx.fillStyle = "#fff"; ctx.font = `900 ${title}px Inter, sans-serif`;
  ctx.fillText(fitText(ctx, o.song || "SONG TITLE", maxW), x, y);
  ctx.fillStyle = "rgba(255,255,255,0.65)"; ctx.font = `600 ${sub}px Inter, sans-serif`;
  ctx.fillText(fitText(ctx, o.artist || "ARTIST", maxW), x, y + gap);
}

function drawProgress(ctx: CanvasRenderingContext2D, o: RenderOpts, L: Layout) {
  const s = L.scale, y = L.info.y + L.info.gap + 90 * s;
  const a = L.info.x, b = L.info.right;
  const cw = (b - a) * (progressPercent(o.current, o.total) / 100);
  ctx.lineCap = "round"; ctx.lineWidth = 8 * s;
  ctx.strokeStyle = "rgba(255,255,255,0.2)"; ctx.beginPath(); ctx.moveTo(a, y); ctx.lineTo(b, y); ctx.stroke();
  ctx.strokeStyle = "#fff"; ctx.beginPath(); ctx.moveTo(a, y); ctx.lineTo(a + cw, y); ctx.stroke();
  ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(a + cw, y, 12 * s, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,0.5)"; ctx.font = `bold ${28 * s}px Inter, sans-serif`;
  ctx.textAlign = "left"; ctx.fillText(o.current, a, y + 48 * s);
  ctx.textAlign = "right"; ctx.fillText(o.total, b, y + 48 * s);
  return y + 48 * s;
}

function drawControls(ctx: CanvasRenderingContext2D, L: Layout, top: number) {
  const s = L.scale, cx = (L.info.x + L.info.right) / 2, cy = top + 110 * s;
  ctx.fillStyle = "#fff";
  // play circle
  ctx.beginPath(); ctx.arc(cx, cy, 60 * s, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = "#000";
  ctx.fillRect(cx - 18 * s, cy - 24 * s, 12 * s, 48 * s); ctx.fillRect(cx + 6 * s, cy - 24 * s, 12 * s, 48 * s);
  ctx.fillStyle = "#fff";
  const tri = (x: number, dir: number) => {
    ctx.beginPath();
    ctx.moveTo(x - dir * 18 * s, cy - 22 * s); ctx.lineTo(x + dir * 18 * s, cy); ctx.lineTo(x - dir * 18 * s, cy + 22 * s); ctx.closePath(); ctx.fill();
    ctx.fillRect(x + dir * 18 * s - (dir > 0 ? 0 : 6 * s), cy - 22 * s, 6 * s, 44 * s);
  };
  tri(cx + 170 * s, 1); tri(cx - 170 * s, -1);
}

/** Single atomic render — generation + export use the same call */
export function renderArtwork(canvas: HTMLCanvasElement, o: RenderOpts) {
  const { w, h } = calculateCanvas(o.ratio);
  canvas.width = w; canvas.height = h;
  const ctx = canvas.getContext("2d")!;
  const L = layout(o.ratio, w, h);
  drawBackground(ctx, o, w, h);
  drawCover(ctx, o, L);
  drawTrackInfo(ctx, o, L);
  const bottom = drawProgress(ctx, o, L);
  if (o.ratio !== "1:1") drawControls(ctx, L, bottom);
}

export async function exportArtwork(o: RenderOpts): Promise<Blob> {
  const c = document.createElement("canvas");
  renderArtwork(c, o);
  return new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error("export failed"))), "image/jpeg", 0.95));
}

export function extractDominantColor(img: HTMLImageElement): string {
  const c = document.createElement("canvas");
  const S = 64; c.width = S; c.height = S;
  const ctx = c.getContext("2d")!;
  ctx.drawImage(img, 0, 0, S, S);
  try {
    const d = ctx.getImageData(0, 0, S, S).data;
    let r = 0, g = 0, b = 0, n = 0;
    for (let i = 0; i < d.length; i += 4) {
      const max = Math.max(d[i], d[i + 1], d[i + 2]), min = Math.min(d[i], d[i + 1], d[i + 2]);
      const wgt = 1 + (max - min) / 32; // favour saturated pixels
      r += d[i] * wgt; g += d[i + 1] * wgt; b += d[i + 2] * wgt; n += wgt;
    }
    return "#" + [r, g, b].map((x) => Math.round(x / n).toString(16).padStart(2, "0")).join("");
  } catch {
    return "#ef4444";
  }
}

const MAX_BYTES = 15 * 1024 * 1024;
const ALLOWED = ["image/jpeg", "image/png", "image/webp"];
export async function validateImage(file: File): Promise<HTMLImageElement> {
  if (!ALLOWED.includes(file.type)) throw new Error("Only JPG, PNG and WEBP are allowed");
  if (file.size > MAX_BYTES) throw new Error("File must not exceed 15MB");
  const url = URL.createObjectURL(file);
  const img = new Image();
  img.src = url;
  try { await img.decode(); } catch { URL.revokeObjectURL(url); throw new Error("Unable to decode image"); }
  if (img.naturalWidth < 300 || img.naturalHeight < 300) { URL.revokeObjectURL(url); throw new Error("Minimum size is 300×300"); }
  return img;
}
