import { useEffect, useRef, useState } from "react";
import { Zap, RefreshCw, UploadCloud, Music2, Package, AlertTriangle } from "lucide-react";
import { RATIOS, Ratio, RenderOpts, renderArtwork, exportArtwork, extractDominantColor, validateImage } from "./lib/renderer";

const label = "block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-1.5";
const input = "w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-red-500 transition-colors";

function download(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export default function App() {
  const [song, setSong] = useState("");
  const [artist, setArtist] = useState("");
  const [color, setColor] = useState("#ef4444");
  const [current, setCurrent] = useState("0:26");
  const [total, setTotal] = useState("1:26");
  const [ratio, setRatio] = useState<Ratio>("9:16");
  const [image, setImage] = useState<HTMLImageElement | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [drag, setDrag] = useState(false);
  const previewRef = useRef<HTMLCanvasElement>(null);
  const urlRef = useRef<string | null>(null);

  useEffect(() => () => { if (urlRef.current) URL.revokeObjectURL(urlRef.current); }, []);

  const opts = (r: Ratio = ratio): RenderOpts | null =>
    image ? { image, ratio: r, song, artist, color, current, total } : null;

  // Live preview = the exact same renderer as export (WYSIWYG)
  useEffect(() => {
    const o = opts();
    if (o && previewRef.current) renderArtwork(previewRef.current, o);
  }, [image, ratio, song, artist, color, current, total]);

  const handleFile = async (file?: File) => {
    if (!file) return;
    setError("");
    try {
      const img = await validateImage(file);
      if (urlRef.current) URL.revokeObjectURL(urlRef.current); // revoke previous immediately
      urlRef.current = img.src;
      setImage(img);
      setColor(extractDominantColor(img));
    } catch (e) {
      setError((e as Error).message);
    }
  };

  const fname = (r: Ratio) => `${(song || "lphonk_track").replace(/\s+/g, "_")}_${r.replace(":", "x")}.jpg`;

  const handleDownload = async (all = false) => {
    if (!image) return;
    setBusy(true);
    try {
      for (const r of all ? RATIOS : [ratio]) {
        download(await exportArtwork(opts(r)!), fname(r));
        if (all) await new Promise((res) => setTimeout(res, 300));
      }
    } finally { setBusy(false); }
  };

  const aspect = { "9:16": "aspect-[9/16] max-w-[260px]", "16:9": "aspect-video max-w-full", "3:4": "aspect-[3/4] max-w-[320px]", "1:1": "aspect-square max-w-[340px]" }[ratio];

  return (
    <div className="min-h-screen bg-black py-10 px-4">
      <div className="max-w-5xl mx-auto p-6 bg-zinc-950 text-white rounded-3xl border border-zinc-800 shadow-2xl">
        <div className="flex items-center gap-3 mb-6 pb-4 border-b border-zinc-800">
          <div className="p-2.5 bg-red-500/10 rounded-xl text-red-500 border border-red-500/20"><Zap className="w-6 h-6" /></div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">LPhonk Spotify Pro</h1>
            <p className="text-xs text-zinc-400">Create track cards in various formats · Browser-side render</p>
          </div>
        </div>

        <div className="mb-6">
          <span className={label}>Select Format</span>
          <div className="grid grid-cols-4 gap-2">
            {RATIOS.map((r) => (
              <button key={r} onClick={() => setRatio(r)}
                className={`py-2.5 rounded-xl font-medium text-sm transition-all border ${ratio === r ? "bg-red-500 border-red-500 shadow-lg shadow-red-500/25" : "bg-zinc-900 text-zinc-400 border-zinc-800 hover:bg-zinc-800 hover:text-white"}`}>
                {r}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div><label className={label}>Track Title</label>
              <input className={input} value={song} onChange={(e) => setSong(e.target.value)} placeholder="e.g. ESPECTRO" /></div>
            <div><label className={label}>Artist / Author</label>
              <input className={input} value={artist} onChange={(e) => setArtist(e.target.value)} placeholder="e.g. DJ ALEX, MC LOCKED" /></div>
            <div className="grid grid-cols-3 gap-3">
              <div><label className={label}>Current</label>
                <input className={input + " text-center"} value={current} onChange={(e) => setCurrent(e.target.value)} /></div>
              <div><label className={label}>Total</label>
                <input className={input + " text-center"} value={total} onChange={(e) => setTotal(e.target.value)} /></div>
              <div><label className={label}>Glow Color</label>
                <input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="w-full h-[46px] bg-zinc-900 border border-zinc-800 rounded-xl cursor-pointer p-1" /></div>
            </div>

            <div>
              <span className={label}>Upload Cover</span>
              <label
                onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
                onDragLeave={() => setDrag(false)}
                onDrop={(e) => { e.preventDefault(); setDrag(false); handleFile(e.dataTransfer.files[0]); }}
                className={`flex flex-col items-center justify-center h-32 border-2 border-dashed rounded-xl cursor-pointer transition-colors ${drag ? "border-red-500 bg-red-500/5" : "border-zinc-800 bg-zinc-900/50 hover:bg-zinc-900"}`}>
                <UploadCloud className="w-8 h-8 mb-2 text-zinc-400" />
                <p className="text-xs text-zinc-400"><span className="font-semibold text-zinc-200">Click</span> or drop image here</p>
                <p className="text-[10px] text-zinc-500 mt-1">JPG / PNG / WEBP · ≤15MB · ≥300×300</p>
                <input type="file" className="hidden" accept="image/jpeg,image/png,image/webp" onChange={(e) => handleFile(e.target.files?.[0])} />
              </label>
              {error && <p className="mt-2 text-xs text-red-400 flex items-center gap-1"><AlertTriangle className="w-3.5 h-3.5" />{error}</p>}
            </div>

            <button onClick={() => handleDownload(false)} disabled={!image || busy}
              className="w-full py-4 bg-red-500 hover:bg-red-600 disabled:opacity-50 disabled:cursor-not-allowed font-bold rounded-xl shadow-lg shadow-red-500/25 flex items-center justify-center gap-2">
              {busy ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Zap className="w-5 h-5" />}
              Download Image ({ratio})
            </button>
            <button onClick={() => handleDownload(true)} disabled={!image || busy}
              className="w-full py-3 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed font-semibold rounded-xl flex items-center justify-center gap-2 text-sm">
              <Package className="w-4 h-4" /> Download All 4 Formats
            </button>
          </div>

          <div className="flex flex-col items-center justify-center bg-zinc-900/30 border border-zinc-800/80 rounded-2xl p-6">
            <span className="text-xs font-medium text-zinc-400 mb-4 uppercase tracking-wider">Live Preview ({ratio})</span>
            <div className={`w-full ${aspect} rounded-xl overflow-hidden border border-zinc-800 shadow-2xl bg-zinc-900 flex items-center justify-center`}>
              {image ? <canvas ref={previewRef} className="w-full h-full" /> : (
                <div className="text-zinc-600 flex flex-col items-center gap-2"><Music2 className="w-10 h-10" /><span className="text-xs">Upload a cover image</span></div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
